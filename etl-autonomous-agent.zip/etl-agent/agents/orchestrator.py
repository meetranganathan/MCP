"""
agents/orchestrator.py
Merges Autosys + Snowflake state into a unified world model.
Persists state between cycles and builds summaries.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("Orchestrator")

STATE_FILE = Path("logs/world_state.json")


class OrchestratorAgent:
    def __init__(self, config):
        self.config     = config
        self._prev_state: dict = self._load_persisted_state()

    def merge_state(self, autosys_jobs: list[dict], sf_meta: dict[str, dict]) -> list[dict]:
        """
        Merge Autosys job state with Snowflake load metadata into a
        single unified world state list that Claude reasons over.
        """
        merged = []
        for job in autosys_jobs:
            job_id     = job["job_id"]
            sf         = sf_meta.get(job_id, {})
            table_name = self.config.job_table_map.get(job_id, "UNKNOWN")
            sla_mins   = self.config.job_sla_minutes.get(job_id, 60)

            merged.append({
                "job_id":           job_id,
                "autosys_box":      job.get("box", ""),
                "snowflake_table":  table_name,
                "status":           job.get("status", "UNKNOWN"),
                "last_start":       job.get("last_start"),
                "last_end":         job.get("last_end"),
                "elapsed_minutes":  job.get("elapsed_minutes", 0),
                "exit_code":        job.get("exit_code"),
                "retry_count":      job.get("retry_count", 0),
                "sla_minutes":      sla_mins,
                "sla_pct_used":     round(job.get("elapsed_minutes", 0) / sla_mins * 100, 1),
                # Snowflake side
                "sf_verified":      sf.get("verified"),
                "sf_today_rows":    sf.get("today_rows"),
                "sf_total_rows":    sf.get("total_rows"),
                "sf_last_load_ts":  sf.get("last_load_ts"),
                "sf_prev_rows":     sf.get("prev_rows"),
                "sf_error":         sf.get("error"),
                # History from prev cycle
                "prev_status":      self._prev_state.get(job_id, {}).get("status"),
                "consecutive_failures": self._count_failures(job_id, job.get("status")),
            })

        return merged

    async def save_state(self, world_state: list[dict], actions: list[dict], cycle: int):
        """Persist world state and cycle actions to disk."""
        state_snapshot = {
            "cycle":      cycle,
            "timestamp":  datetime.now().isoformat(),
            "jobs":       {j["job_id"]: j for j in world_state},
            "actions":    actions,
        }

        # Append to rotating JSON log
        history_file = Path(f"logs/cycle_{datetime.now():%Y%m%d}.jsonl")
        with open(history_file, "a") as f:
            f.write(json.dumps(state_snapshot) + "\n")

        # Save latest state for next cycle comparison
        STATE_FILE.parent.mkdir(exist_ok=True)
        with open(STATE_FILE, "w") as f:
            json.dump(state_snapshot, f, indent=2, default=str)

        self._prev_state = state_snapshot["jobs"]
        logger.info(f"  State persisted to {STATE_FILE}")

    def build_summary(self, world_state: list[dict], actions: list[dict]) -> str:
        total    = len(world_state)
        success  = sum(1 for j in world_state if j["status"] == "SUCCESS")
        failed   = sum(1 for j in world_state if j["status"] == "FAILURE")
        running  = sum(1 for j in world_state if j["status"] == "RUNNING")
        restarts = sum(1 for a in actions if a.get("tool") == "restart_job")
        alerts   = sum(1 for a in actions if a.get("tool") in ("send_slack_alert", "send_email_alert"))

        return (f"{total} jobs | {success} OK | {failed} FAIL | {running} running | "
                f"{restarts} restarts | {alerts} alerts sent")

    def _load_persisted_state(self) -> dict:
        """Load previous cycle state from disk if available."""
        if STATE_FILE.exists():
            try:
                with open(STATE_FILE) as f:
                    data = json.load(f)
                    return data.get("jobs", {})
            except Exception:
                pass
        return {}

    def _count_failures(self, job_id: str, current_status: str) -> int:
        """Track consecutive failures across cycles."""
        prev = self._prev_state.get(job_id, {})
        if current_status == "FAILURE" and prev.get("status") == "FAILURE":
            return prev.get("consecutive_failures", 0) + 1
        return 1 if current_status == "FAILURE" else 0
