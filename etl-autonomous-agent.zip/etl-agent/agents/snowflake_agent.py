"""
agents/snowflake_agent.py
Queries Snowflake to verify ETL loads, check row counts, and detect anomalies.
Uses snowflake-connector-python directly (or can be swapped for Snowflake MCP).
"""

import logging
from datetime import datetime, date
from typing import Optional

import snowflake.connector

logger = logging.getLogger("SnowflakeAgent")


class SnowflakeInspectorAgent:
    """
    Connects to Snowflake and performs post-load verification:
    - Row count checks vs baseline
    - Load timestamp validation
    - Error/rejection scanning
    - Delta anomaly detection
    """

    def __init__(self, config):
        self.config = config
        self._conn  = None
        # In-memory baseline: {table_name: {"rows": int, "load_ts": str}}
        self._baselines: dict[str, dict] = {}

    # ── Connection ────────────────────────────────────────────────────────────

    def _get_conn(self):
        """Lazy Snowflake connection with auto-reconnect."""
        if self._conn is None or self._conn.is_closed():
            logger.info("  Connecting to Snowflake...")
            self._conn = snowflake.connector.connect(
                account   = self.config.snowflake_account,
                user      = self.config.snowflake_user,
                password  = self.config.snowflake_password,
                warehouse = self.config.snowflake_warehouse,
                database  = self.config.snowflake_database,
                schema    = self.config.snowflake_schema,
                role      = self.config.snowflake_role,
            )
        return self._conn

    def _query(self, sql: str, params: tuple = ()) -> list[dict]:
        """Execute a query and return list of row dicts."""
        conn   = self._get_conn()
        cursor = conn.cursor()
        try:
            cursor.execute(sql, params)
            cols = [desc[0].lower() for desc in cursor.description]
            return [dict(zip(cols, row)) for row in cursor.fetchall()]
        finally:
            cursor.close()

    # ── Public methods ────────────────────────────────────────────────────────

    async def get_load_metadata(self, jobs: list[dict]) -> dict[str, dict]:
        """
        For each job with a known Snowflake table mapping,
        fetch load metadata to enrich the world state.
        """
        meta = {}
        for job in jobs:
            table = self.config.job_table_map.get(job["job_id"])
            if table:
                try:
                    meta[job["job_id"]] = await self.verify_load(table)
                except Exception as e:
                    meta[job["job_id"]] = {"error": str(e)}
        return meta

    async def verify_load(self, table_name: str, schema: str = None) -> dict:
        """
        Verify today's load for a Snowflake table:
        - Was it loaded today?
        - What's the row count?
        - What was the load timestamp?
        """
        schema     = schema or self.config.snowflake_schema
        full_table = f"{self.config.snowflake_database}.{schema}.{table_name}"

        logger.info(f"  Verifying load: {full_table}")

        # Check for a standard LOAD_TS or LOAD_DT column
        rows = self._query(f"""
            SELECT
                COUNT(*)                              AS row_count,
                MAX(LOAD_TS)                          AS last_load_ts,
                COUNT(CASE WHEN LOAD_DT = CURRENT_DATE THEN 1 END) AS today_rows
            FROM {full_table}
        """)

        if not rows:
            return {"table": full_table, "verified": False, "reason": "No rows returned"}

        r          = rows[0]
        today_rows = r.get("today_rows", 0) or 0
        total_rows = r.get("row_count", 0) or 0

        # Save baseline for delta comparison
        prev = self._baselines.get(table_name, {})
        self._baselines[table_name] = {
            "rows":     total_rows,
            "load_ts":  str(r.get("last_load_ts")),
            "checked":  datetime.now().isoformat(),
        }

        return {
            "table":        full_table,
            "verified":     today_rows > 0,
            "today_rows":   today_rows,
            "total_rows":   total_rows,
            "last_load_ts": str(r.get("last_load_ts")),
            "prev_rows":    prev.get("rows"),
        }

    async def get_row_count(self, table_name: str, where_clause: str = None) -> dict:
        """Get row count, optionally filtered."""
        schema     = self.config.snowflake_schema
        full_table = f"{self.config.snowflake_database}.{schema}.{table_name}"

        sql = f"SELECT COUNT(*) AS cnt FROM {full_table}"
        if where_clause:
            sql += f" WHERE {where_clause}"

        rows  = self._query(sql)
        count = rows[0]["cnt"] if rows else 0

        logger.info(f"  Row count {full_table}: {count:,}")
        return {"table": full_table, "row_count": count, "filter": where_clause}

    async def get_load_errors(self, table_name: str) -> dict:
        """
        Check for errors in Snowflake load history or a dedicated error table.
        Adjust the query to match your error tracking pattern.
        """
        schema = self.config.snowflake_schema
        try:
            # Option 1: Check COPY_HISTORY (for Snowpipe / COPY INTO loads)
            rows = self._query(f"""
                SELECT
                    FILE_NAME,
                    ROWS_LOADED,
                    ROWS_PARSED,
                    FIRST_ERROR_MESSAGE,
                    STATUS
                FROM TABLE(INFORMATION_SCHEMA.COPY_HISTORY(
                    TABLE_NAME => '{table_name}',
                    START_TIME => DATEADD('hour', -24, CURRENT_TIMESTAMP)
                ))
                WHERE STATUS != 'Loaded'
                ORDER BY LAST_LOAD_TIME DESC
                LIMIT 10
            """)
            return {"table": table_name, "errors": rows, "source": "COPY_HISTORY"}

        except Exception:
            # Option 2: Fallback — check a custom ETL_ERRORS table if you have one
            try:
                rows = self._query(f"""
                    SELECT ERROR_MSG, ROW_COUNT, LOAD_TS
                    FROM {self.config.snowflake_database}.{schema}.ETL_ERRORS
                    WHERE TABLE_NAME = %s
                      AND LOAD_TS >= CURRENT_DATE
                    ORDER BY LOAD_TS DESC LIMIT 20
                """, (table_name,))
                return {"table": table_name, "errors": rows, "source": "ETL_ERRORS"}
            except Exception as e2:
                return {"table": table_name, "errors": [], "note": f"Could not query errors: {e2}"}

    async def compare_delta(self, table_name: str, threshold_pct: float = 2.0) -> dict:
        """
        Compare today's row count to yesterday's baseline.
        Returns anomaly flag if delta exceeds threshold_pct.
        """
        today   = await self.get_row_count(table_name, "LOAD_DT = CURRENT_DATE")
        yest    = await self.get_row_count(table_name, "LOAD_DT = DATEADD(day, -1, CURRENT_DATE)")

        today_n = today.get("row_count", 0) or 0
        yest_n  = yest.get("row_count",  0) or 1   # avoid div by zero

        delta   = today_n - yest_n
        pct     = abs(delta / yest_n) * 100

        is_anomaly = pct > threshold_pct

        logger.info(f"  Delta check {table_name}: today={today_n:,} yest={yest_n:,} "
                    f"delta={delta:+,} ({pct:.1f}%) anomaly={is_anomaly}")

        return {
            "table":         table_name,
            "today_rows":    today_n,
            "yesterday_rows": yest_n,
            "delta":         delta,
            "delta_pct":     round(pct, 2),
            "threshold_pct": threshold_pct,
            "is_anomaly":    is_anomaly,
            "direction":     "increase" if delta > 0 else "decrease",
        }

    def close(self):
        if self._conn and not self._conn.is_closed():
            self._conn.close()
