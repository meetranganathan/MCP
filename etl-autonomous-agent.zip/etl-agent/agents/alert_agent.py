"""
agents/alert_agent.py
Dispatches alerts via Slack, email, and incident log.
"""

import json
import logging
import smtplib
from datetime import datetime
from email.mime.text import MIMEText
from pathlib import Path

import httpx

logger = logging.getLogger("AlertAgent")

INCIDENT_LOG = Path("logs/incidents.jsonl")

SEVERITY_EMOJI = {
    "info":     "ℹ️",
    "warning":  "⚠️",
    "critical": "🚨",
    "medium":   "⚠️",
    "high":     "🔴",
    "low":      "🟡",
}

SLACK_COLORS = {
    "info":     "#36a64f",
    "warning":  "#fbbf24",
    "critical": "#ef4444",
}


class AlertDispatchAgent:
    def __init__(self, config):
        self.config = config

    async def send_slack(self, channel: str, message: str, severity: str = "warning") -> dict:
        """Post a formatted alert to a Slack channel via webhook."""
        if not self.config.slack_webhook_url:
            logger.warning("  Slack webhook not configured — skipping")
            return {"status": "skipped", "reason": "no webhook configured"}

        emoji   = SEVERITY_EMOJI.get(severity, "⚠️")
        color   = SLACK_COLORS.get(severity, "#fbbf24")
        payload = {
            "channel": channel,
            "attachments": [{
                "color":   color,
                "pretext": f"{emoji} *ETL Monitor Alert*",
                "text":    message,
                "footer":  f"ETL Agent | {datetime.now():%Y-%m-%d %H:%M:%S}",
                "mrkdwn_in": ["text", "pretext"],
            }]
        }

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self.config.slack_webhook_url,
                    json=payload,
                    timeout=10
                )
                resp.raise_for_status()
                logger.info(f"  Slack alert sent to {channel} [{severity}]")
                return {"status": "sent", "channel": channel, "severity": severity}
        except Exception as e:
            logger.error(f"  Slack alert failed: {e}")
            return {"status": "error", "error": str(e)}

    async def send_email(self, recipients: list[str], subject: str, body: str) -> dict:
        """Send an email alert via SMTP."""
        if not self.config.smtp_host:
            logger.warning("  SMTP not configured — skipping email")
            return {"status": "skipped", "reason": "no SMTP configured"}

        try:
            msg              = MIMEText(body, "plain")
            msg["Subject"]   = f"[ETL Alert] {subject}"
            msg["From"]      = self.config.alert_from_email
            msg["To"]        = ", ".join(recipients)

            with smtplib.SMTP(self.config.smtp_host, self.config.smtp_port) as server:
                if self.config.smtp_tls:
                    server.starttls()
                if self.config.smtp_user:
                    server.login(self.config.smtp_user, self.config.smtp_password)
                server.sendmail(self.config.alert_from_email, recipients, msg.as_string())

            logger.info(f"  Email sent to {recipients}: {subject}")
            return {"status": "sent", "recipients": recipients, "subject": subject}
        except Exception as e:
            logger.error(f"  Email failed: {e}")
            return {"status": "error", "error": str(e)}

    async def log_incident(self, job_id: str, description: str, severity: str = "medium") -> dict:
        """Append an incident record to the incident log."""
        incident = {
            "id":          f"INC-{datetime.now():%Y%m%d%H%M%S}-{job_id}",
            "job_id":      job_id,
            "description": description,
            "severity":    severity,
            "timestamp":   datetime.now().isoformat(),
            "status":      "open",
        }

        INCIDENT_LOG.parent.mkdir(exist_ok=True)
        with open(INCIDENT_LOG, "a") as f:
            f.write(json.dumps(incident) + "\n")

        logger.info(f"  Incident logged: {incident['id']} [{severity}] {job_id}")
        return {"status": "logged", "incident_id": incident["id"], "severity": severity}
