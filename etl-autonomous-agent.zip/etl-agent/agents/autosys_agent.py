"""
agents/autosys_agent.py
Wraps your custom Autosys MCP server with async methods.
Supports both CLI (senq/autorep) and REST API modes.
"""

import asyncio
import json
import logging
import subprocess
from datetime import datetime, timedelta
from typing import Optional

import httpx

logger = logging.getLogger("AutosysAgent")


class AutosysMonitorAgent:
    """
    Interfaces with Autosys via:
      - Mode "cli":  runs senq / autorep shell commands (if agent server has access)
      - Mode "rest": calls your Autosys MCP REST server (recommended for VS Code)
    """

    def __init__(self, config):
        self.config  = config
        self.mode    = config.autosys_mode   # "cli" | "rest"
        self.base_url = config.autosys_mcp_url  # e.g. http://localhost:8080
        self._retry_counts: dict[str, int] = {}  # tracks restart attempts per job

    # ── Public methods (called by agent_loop.py tool dispatcher) ─────────────

    async def poll_all(self, job_ids: list[str]) -> list[dict]:
        """Poll all monitored jobs and return their current state."""
        results = []
        for job_id in job_ids:
            status = await self.get_job_status(job_id)
            results.append(status)
        return results

    async def get_job_status(self, job_id: str) -> dict:
        """Get current Autosys job status with metadata."""
        logger.info(f"  Polling job: {job_id}")
        try:
            if self.mode == "rest":
                return await self._rest_get_status(job_id)
            else:
                return await self._cli_get_status(job_id)
        except Exception as e:
            logger.error(f"  Failed to get status for {job_id}: {e}")
            return self._error_status(job_id, str(e))

    async def get_job_history(self, job_id: str, days: int = 7) -> dict:
        """Get job run history for the past N days."""
        try:
            if self.mode == "rest":
                async with httpx.AsyncClient() as client:
                    resp = await client.get(
                        f"{self.base_url}/jobs/{job_id}/history",
                        params={"days": days},
                        timeout=10
                    )
                    return resp.json()
            else:
                since = (datetime.now() - timedelta(days=days)).strftime("%m/%d/%Y")
                cmd   = f"autorep -j {job_id} -d -r {since}"
                out   = await self._run_cli(cmd)
                return self._parse_history(job_id, out)
        except Exception as e:
            return {"job_id": job_id, "error": str(e), "history": []}

    async def restart_job(self, job_id: str) -> dict:
        """Restart a failed job. Tracks retry count."""
        count = self._retry_counts.get(job_id, 0)
        self._retry_counts[job_id] = count + 1

        logger.info(f"  Restarting job: {job_id} (attempt #{count + 1})")
        try:
            if self.mode == "rest":
                async with httpx.AsyncClient() as client:
                    resp = await client.post(
                        f"{self.base_url}/jobs/{job_id}/restart",
                        timeout=15
                    )
                    result = resp.json()
            else:
                cmd    = f"senq -e {job_id} -q {self.config.autosys_queue}"
                out    = await self._run_cli(cmd)
                result = {"status": "restarted", "output": out}

            return {
                "job_id":        job_id,
                "action":        "restart",
                "attempt":       count + 1,
                "result":        result,
                "timestamp":     datetime.now().isoformat(),
            }
        except Exception as e:
            return {"job_id": job_id, "action": "restart", "error": str(e)}

    async def release_hold(self, job_id: str) -> dict:
        """Release an ON_ICE (held) job."""
        logger.info(f"  Releasing hold on: {job_id}")
        try:
            if self.mode == "rest":
                async with httpx.AsyncClient() as client:
                    resp = await client.post(
                        f"{self.base_url}/jobs/{job_id}/release",
                        timeout=10
                    )
                    return resp.json()
            else:
                cmd = f"senq -e {job_id} -ov"
                out = await self._run_cli(cmd)
                return {"job_id": job_id, "action": "release_hold", "output": out}
        except Exception as e:
            return {"job_id": job_id, "action": "release_hold", "error": str(e)}

    async def get_box_status(self, box_name: str) -> dict:
        """Get the status of an Autosys box and its contained jobs."""
        try:
            if self.mode == "rest":
                async with httpx.AsyncClient() as client:
                    resp = await client.get(f"{self.base_url}/boxes/{box_name}", timeout=10)
                    return resp.json()
            else:
                cmd = f"autorep -J {box_name} -q"
                out = await self._run_cli(cmd)
                return self._parse_box(box_name, out)
        except Exception as e:
            return {"box_name": box_name, "error": str(e)}

    # ── REST helpers ──────────────────────────────────────────────────────────

    async def _rest_get_status(self, job_id: str) -> dict:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.base_url}/jobs/{job_id}/status",
                timeout=10
            )
            resp.raise_for_status()
            data = resp.json()
            return {
                "job_id":          job_id,
                "status":          data.get("status", "UNKNOWN"),
                "last_start":      data.get("last_start"),
                "last_end":        data.get("last_end"),
                "elapsed_minutes": data.get("elapsed_minutes", 0),
                "exit_code":       data.get("exit_code"),
                "machine":         data.get("machine"),
                "box":             data.get("box"),
                "retry_count":     self._retry_counts.get(job_id, 0),
            }

    # ── CLI helpers ───────────────────────────────────────────────────────────

    async def _cli_get_status(self, job_id: str) -> dict:
        """
        Uses autorep CLI — adjust parsing to match your Autosys version output.
        Sample output:
          Job Name         Last Start   Last End     St   Exit Cd  Run
          LOAD_SALES_FACT  06/02 05:02  06/02 05:47  SU   0        3
        """
        cmd = f"autorep -j {job_id} -q"
        out = await self._run_cli(cmd)
        return self._parse_status_line(job_id, out)

    async def _run_cli(self, cmd: str) -> str:
        """Execute an Autosys CLI command asynchronously."""
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        if proc.returncode != 0:
            raise RuntimeError(f"CLI error ({proc.returncode}): {stderr.decode()}")
        return stdout.decode()

    def _parse_status_line(self, job_id: str, output: str) -> dict:
        """Parse autorep -q output into a status dict."""
        STATUS_MAP = {
            "SU": "SUCCESS", "FA": "FAILURE", "RU": "RUNNING",
            "OH": "ON_ICE",  "IN": "INACTIVE", "AC": "ACTIVATED",
            "WA": "WAITING",
        }
        for line in output.splitlines():
            if job_id in line:
                parts = line.split()
                if len(parts) >= 5:
                    st_code = parts[4] if len(parts) > 4 else "IN"
                    return {
                        "job_id":      job_id,
                        "status":      STATUS_MAP.get(st_code, st_code),
                        "last_start":  parts[1] if len(parts) > 1 else None,
                        "last_end":    parts[2] if len(parts) > 2 else None,
                        "exit_code":   parts[5] if len(parts) > 5 else None,
                        "retry_count": self._retry_counts.get(job_id, 0),
                    }
        return self._error_status(job_id, "Job not found in autorep output")

    def _parse_history(self, job_id: str, output: str) -> dict:
        runs = []
        for line in output.splitlines():
            if job_id in line:
                parts = line.split()
                runs.append({"line": " ".join(parts)})
        return {"job_id": job_id, "history": runs}

    def _parse_box(self, box_name: str, output: str) -> dict:
        return {"box_name": box_name, "raw": output[:500]}

    def _error_status(self, job_id: str, error: str) -> dict:
        return {"job_id": job_id, "status": "UNKNOWN", "error": error}
