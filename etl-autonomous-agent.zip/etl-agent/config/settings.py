"""
config/settings.py
Loads agent configuration from environment variables or .env file.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent.parent / ".env")
except ImportError:
    pass


@dataclass
class AgentConfig:
    # ── Anthropic ─────────────────────────────────────────────────────────────
    anthropic_api_key: str = ""

    # ── Autosys ───────────────────────────────────────────────────────────────
    autosys_mode:    str = "rest"          # "cli" or "rest"
    autosys_mcp_url: str = "http://localhost:8080"
    autosys_queue:   str = "DEFAULT"

    # ── Snowflake ─────────────────────────────────────────────────────────────
    snowflake_account:   str = ""
    snowflake_user:      str = ""
    snowflake_password:  str = ""
    snowflake_warehouse: str = "COMPUTE_WH"
    snowflake_database:  str = "PROD"
    snowflake_schema:    str = "DW"
    snowflake_role:      str = "ETL_MONITOR_ROLE"

    # ── Alerts ────────────────────────────────────────────────────────────────
    slack_webhook_url:  str = ""
    alert_from_email:   str = "etl-agent@yourcompany.com"
    smtp_host:          str = ""
    smtp_port:          int = 587
    smtp_tls:           bool = True
    smtp_user:          str = ""
    smtp_password:      str = ""
    alert_recipients:   list = field(default_factory=list)

    # ── Agent behavior ────────────────────────────────────────────────────────
    poll_interval_seconds: int = 300   # 5 minutes between cycles

    # ── Job registry — map job_id → Snowflake table ───────────────────────────
    job_table_map: dict = field(default_factory=lambda: {
        "LOAD_SALES_FACT":    "SALES_FACT",
        "LOAD_ORDERS_FACT":   "ORDERS_FACT",
        "LOAD_CUSTOMER_DIM":  "CUSTOMER_DIM",
        "LOAD_PRODUCT_DIM":   "PRODUCT_DIM",
        "LOAD_FINANCE_AGG":   "FINANCE_AGG",
        "LOAD_INVENTORY":     "INVENTORY_SNAP",
        # Add your jobs here
    })

    # ── SLA registry — map job_id → max runtime in minutes ───────────────────
    job_sla_minutes: dict = field(default_factory=lambda: {
        "LOAD_SALES_FACT":    60,
        "LOAD_ORDERS_FACT":   45,
        "LOAD_CUSTOMER_DIM":  30,
        "LOAD_PRODUCT_DIM":   20,
        "LOAD_FINANCE_AGG":   90,
        "LOAD_INVENTORY":     40,
        # Add your SLAs here
    })

    @property
    def monitored_jobs(self) -> list[str]:
        return list(self.job_table_map.keys())

    @classmethod
    def load(cls, env: str = "prod") -> "AgentConfig":
        """Load config from environment variables."""
        prefix = env.upper()   # supports PROD_, UAT_, DEV_ prefixed vars

        def get(key: str, default: str = "") -> str:
            # Try env-prefixed first (e.g. PROD_SNOWFLAKE_ACCOUNT), then plain
            return (os.getenv(f"{prefix}_{key}")
                    or os.getenv(key)
                    or default)

        return cls(
            anthropic_api_key    = get("ANTHROPIC_API_KEY"),
            autosys_mode         = get("AUTOSYS_MODE", "rest"),
            autosys_mcp_url      = get("AUTOSYS_MCP_URL", "http://localhost:8080"),
            autosys_queue        = get("AUTOSYS_QUEUE", "DEFAULT"),
            snowflake_account    = get("SNOWFLAKE_ACCOUNT"),
            snowflake_user       = get("SNOWFLAKE_USER"),
            snowflake_password   = get("SNOWFLAKE_PASSWORD"),
            snowflake_warehouse  = get("SNOWFLAKE_WAREHOUSE", "COMPUTE_WH"),
            snowflake_database   = get("SNOWFLAKE_DATABASE", "PROD"),
            snowflake_schema     = get("SNOWFLAKE_SCHEMA", "DW"),
            snowflake_role       = get("SNOWFLAKE_ROLE", "ETL_MONITOR_ROLE"),
            slack_webhook_url    = get("SLACK_WEBHOOK_URL"),
            alert_from_email     = get("ALERT_FROM_EMAIL", "etl-agent@yourcompany.com"),
            smtp_host            = get("SMTP_HOST"),
            smtp_port            = int(get("SMTP_PORT", "587")),
            smtp_tls             = get("SMTP_TLS", "true").lower() == "true",
            smtp_user            = get("SMTP_USER"),
            smtp_password        = get("SMTP_PASSWORD"),
            alert_recipients     = get("ALERT_RECIPIENTS", "").split(","),
            poll_interval_seconds = int(get("POLL_INTERVAL_SECONDS", "300")),
        )
