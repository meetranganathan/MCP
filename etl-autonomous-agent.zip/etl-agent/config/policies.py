"""
config/policies.py
Defines the autonomous decision rules the agent follows.
Claude reads these policies as part of its reasoning prompt.
"""

import logging
from dataclasses import dataclass, field

logger = logging.getLogger("Policies")


@dataclass
class DecisionPolicies:
    config: object

    # ── Restart policies ──────────────────────────────────────────────────────
    max_auto_restarts: int = 2           # Never auto-restart more than this many times
    restart_on_first_failure: bool = True
    no_restart_jobs: list = field(default_factory=list)   # Jobs that must NEVER be auto-restarted

    # ── SLA policies ──────────────────────────────────────────────────────────
    sla_warn_pct: float = 80.0           # Warn at 80% of SLA consumed
    sla_critical_pct: float = 95.0      # Critical alert at 95%

    # ── Row count anomaly policies ────────────────────────────────────────────
    row_delta_warn_pct: float = 2.0      # Warn if row count changes more than 2%
    row_delta_critical_pct: float = 10.0 # Critical if > 10%
    zero_rows_is_critical: bool = True   # Flag if table loads 0 rows as critical

    # ── Escalation policies ───────────────────────────────────────────────────
    escalate_after_failures: int = 2     # Page oncall after this many consecutive failures
    escalate_channel: str = "#etl-oncall"
    normal_channel: str = "#etl-alerts"

    def __post_init__(self):
        # Load no-restart list from config if available
        self.no_restart_jobs = getattr(self.config, "no_restart_jobs", [])

    # ── Policy check methods (called as tools by agent_loop.py) ──────────────

    def should_restart(self, job_id: str, failure_count: int = 1) -> dict:
        """
        Returns whether a failed job should be auto-restarted.
        Claude calls this before issuing any restart.
        """
        if job_id in self.no_restart_jobs:
            return {
                "should_restart": False,
                "reason": f"{job_id} is on the no-restart list — manual intervention required",
                "action": "escalate"
            }

        if failure_count > self.max_auto_restarts:
            return {
                "should_restart": False,
                "reason": f"Exceeded max auto-restarts ({self.max_auto_restarts}). Escalating.",
                "action": "escalate",
                "channel": self.escalate_channel,
            }

        if failure_count == 1 and self.restart_on_first_failure:
            return {
                "should_restart": True,
                "reason": "First failure — auto-restart policy allows one retry",
                "attempt": failure_count,
            }

        return {
            "should_restart": True,
            "reason": f"Within retry limit ({failure_count}/{self.max_auto_restarts})",
            "attempt": failure_count,
        }

    def check_sla(self, job_id: str, elapsed_minutes: float) -> dict:
        """Check job SLA status and return recommended action."""
        sla_mins = self.config.job_sla_minutes.get(job_id, 60)
        pct_used = (elapsed_minutes / sla_mins) * 100

        if pct_used >= self.sla_critical_pct:
            return {
                "status":  "CRITICAL",
                "pct_used": round(pct_used, 1),
                "sla_mins": sla_mins,
                "elapsed":  elapsed_minutes,
                "action":  "send_critical_alert",
                "channel": self.escalate_channel,
                "message": f"🚨 {job_id} at {pct_used:.0f}% of SLA ({elapsed_minutes}m / {sla_mins}m) — SLA breach imminent!",
            }
        if pct_used >= self.sla_warn_pct:
            return {
                "status":  "WARNING",
                "pct_used": round(pct_used, 1),
                "sla_mins": sla_mins,
                "elapsed":  elapsed_minutes,
                "action":  "send_warning_alert",
                "channel": self.normal_channel,
                "message": f"⚠️ {job_id} at {pct_used:.0f}% of SLA ({elapsed_minutes}m / {sla_mins}m)",
            }
        return {
            "status":   "OK",
            "pct_used": round(pct_used, 1),
            "sla_mins": sla_mins,
            "elapsed":  elapsed_minutes,
            "action":   "none",
        }

    def as_prompt_text(self) -> str:
        """Returns a human-readable policy summary for the Claude system prompt."""
        return f"""
- Auto-restart on first failure: {self.restart_on_first_failure}
- Max auto-restarts before escalation: {self.max_auto_restarts}
- Jobs that must NEVER be auto-restarted: {self.no_restart_jobs or 'none'}
- SLA warning threshold: {self.sla_warn_pct}% consumed
- SLA critical threshold: {self.sla_critical_pct}% consumed
- Row count anomaly warning: >{self.row_delta_warn_pct}% delta
- Row count anomaly critical: >{self.row_delta_critical_pct}% delta
- Zero rows loaded = critical alert: {self.zero_rows_is_critical}
- Escalate to {self.escalate_channel} after {self.escalate_after_failures} consecutive failures
- Normal alerts go to: {self.normal_channel}
""".strip()
