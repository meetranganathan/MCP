"""
=============================================================================
  AUTONOMOUS ETL MONITORING AGENT — agent_loop.py
  Observe → Think → Act → Update loop using Claude + MCP tools
=============================================================================
  Run:   python agent_loop.py
  Or:    python agent_loop.py --once        (single cycle, then exit)
  Or:    python agent_loop.py --job JOB_ID  (check one specific job)
=============================================================================
"""

import asyncio
import argparse
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

import anthropic

from agents.orchestrator    import OrchestratorAgent
from agents.autosys_agent   import AutosysMonitorAgent
from agents.snowflake_agent import SnowflakeInspectorAgent
from agents.alert_agent     import AlertDispatchAgent
from config.settings        import AgentConfig
from config.policies        import DecisionPolicies

# ─── LOGGING ─────────────────────────────────────────────────────────────────
log_path = Path("logs") / f"agent_{datetime.now():%Y%m%d}.log"
log_path.parent.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.FileHandler(log_path),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("ETLAgent")


# ─── MAIN AUTONOMOUS LOOP ─────────────────────────────────────────────────────
async def run_agent(config: AgentConfig, once: bool = False, target_job: str = None):
    """
    Core autonomous agent loop.

    Each cycle:
      1. OBSERVE  — poll Autosys job states + Snowflake metadata
      2. THINK    — send observations to Claude with tools, get decisions
      3. ACT      — execute tool calls Claude returns (restart, alert, verify)
      4. UPDATE   — persist new world state, schedule next cycle
    """
    client = anthropic.Anthropic(api_key=config.anthropic_api_key)

    orchestrator    = OrchestratorAgent(config)
    autosys_agent   = AutosysMonitorAgent(config)
    snowflake_agent = SnowflakeInspectorAgent(config)
    alert_agent     = AlertDispatchAgent(config)
    policies        = DecisionPolicies(config)

    cycle = 0

    while True:
        cycle += 1
        logger.info(f"═══ CYCLE #{cycle} STARTED ═══════════════════════════════════")

        # ── PHASE 1: OBSERVE ────────────────────────────────────────────────
        logger.info("Phase 1: OBSERVE — collecting environment state")

        job_filter = [target_job] if target_job else config.monitored_jobs
        raw_jobs   = await autosys_agent.poll_all(job_filter)
        sf_meta    = await snowflake_agent.get_load_metadata(raw_jobs)
        world_state = orchestrator.merge_state(raw_jobs, sf_meta)

        logger.info(f"  Observed {len(world_state)} jobs: "
                    f"{sum(1 for j in world_state if j['status']=='SUCCESS')} SUCCESS, "
                    f"{sum(1 for j in world_state if j['status']=='FAILURE')} FAILURE, "
                    f"{sum(1 for j in world_state if j['status']=='RUNNING')} RUNNING")

        # ── PHASE 2: THINK — send to Claude for autonomous reasoning ────────
        logger.info("Phase 2: THINK — Claude reasoning over job states")

        agent_prompt = build_agent_prompt(world_state, policies, cycle)
        messages     = [{"role": "user", "content": agent_prompt}]
        tools        = get_all_tools()

        # Agentic loop: Claude decides what tools to call
        actions_taken = []
        while True:
            response = client.messages.create(
                model       = "claude-opus-4-5",
                max_tokens  = 4096,
                system      = SYSTEM_PROMPT,
                tools       = tools,
                messages    = messages,
            )

            logger.info(f"  Claude stop_reason: {response.stop_reason}")

            # Collect any text reasoning Claude outputs
            for block in response.content:
                if block.type == "text":
                    logger.info(f"  [Agent reasoning] {block.text[:300]}")

            if response.stop_reason == "end_turn":
                break  # Claude is done deciding

            if response.stop_reason != "tool_use":
                break

            # ── PHASE 3: ACT — execute tool calls Claude requested ──────────
            logger.info("Phase 3: ACT — executing tool calls")

            tool_results = []
            for block in response.content:
                if block.type != "tool_use":
                    continue

                tool_name  = block.name
                tool_input = block.input
                logger.info(f"  → Tool call: {tool_name}({json.dumps(tool_input)})")

                result = await dispatch_tool(
                    tool_name, tool_input,
                    autosys_agent, snowflake_agent, alert_agent, policies
                )

                logger.info(f"  ← Result: {str(result)[:200]}")
                actions_taken.append({"tool": tool_name, "input": tool_input, "result": result})

                tool_results.append({
                    "type":        "tool_result",
                    "tool_use_id": block.id,
                    "content":     json.dumps(result),
                })

            # Feed results back to Claude for next reasoning step
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user",      "content": tool_results})

        # ── PHASE 4: UPDATE — persist state ─────────────────────────────────
        logger.info("Phase 4: UPDATE — persisting world state")
        await orchestrator.save_state(world_state, actions_taken, cycle)

        summary = orchestrator.build_summary(world_state, actions_taken)
        logger.info(f"  Cycle summary: {summary}")
        logger.info(f"═══ CYCLE #{cycle} COMPLETE — {len(actions_taken)} actions taken ═══\n")

        if once:
            logger.info("--once flag set. Exiting after single cycle.")
            break

        logger.info(f"  Sleeping {config.poll_interval_seconds}s until next cycle...")
        await asyncio.sleep(config.poll_interval_seconds)


# ─── TOOL DISPATCHER ─────────────────────────────────────────────────────────
async def dispatch_tool(name, inputs, autosys, snowflake, alerts, policies):
    """Routes Claude's tool calls to the right agent method."""
    dispatch = {
        # Autosys tools
        "get_job_status":    lambda: autosys.get_job_status(inputs["job_id"]),
        "get_job_history":   lambda: autosys.get_job_history(inputs["job_id"], inputs.get("days", 7)),
        "restart_job":       lambda: autosys.restart_job(inputs["job_id"]),
        "release_job_hold":  lambda: autosys.release_hold(inputs["job_id"]),
        "get_box_status":    lambda: autosys.get_box_status(inputs["box_name"]),
        # Snowflake tools
        "verify_table_load": lambda: snowflake.verify_load(inputs["table_name"], inputs.get("schema", "DW")),
        "get_row_count":     lambda: snowflake.get_row_count(inputs["table_name"], inputs.get("where_clause")),
        "get_load_errors":   lambda: snowflake.get_load_errors(inputs["table_name"]),
        "compare_row_delta": lambda: snowflake.compare_delta(inputs["table_name"], inputs.get("threshold_pct", 2.0)),
        # Alert tools
        "send_slack_alert":  lambda: alerts.send_slack(inputs["channel"], inputs["message"], inputs.get("severity", "warning")),
        "send_email_alert":  lambda: alerts.send_email(inputs["recipients"], inputs["subject"], inputs["body"]),
        "log_incident":      lambda: alerts.log_incident(inputs["job_id"], inputs["description"], inputs.get("severity", "medium")),
        # Policy tools
        "check_sla_status":  lambda: policies.check_sla(inputs["job_id"], inputs["elapsed_minutes"]),
        "should_auto_restart": lambda: policies.should_restart(inputs["job_id"], inputs.get("failure_count", 1)),
    }

    handler = dispatch.get(name)
    if handler is None:
        return {"error": f"Unknown tool: {name}"}

    try:
        result = handler()
        return await result if asyncio.iscoroutine(result) else result
    except Exception as e:
        logger.error(f"Tool {name} failed: {e}")
        return {"error": str(e), "tool": name}


# ─── AGENT PROMPT ─────────────────────────────────────────────────────────────
def build_agent_prompt(world_state: list, policies: DecisionPolicies, cycle: int) -> str:
    return f"""
You are an autonomous ETL monitoring agent. This is cycle #{cycle}.

## Current Job States (Autosys + Snowflake)
{json.dumps(world_state, indent=2)}

## Your Decision Policies
{policies.as_prompt_text()}

## Your Task
Analyze every job above. For each job:
1. Determine if any autonomous action is required
2. Call the appropriate tools to investigate, remediate, or alert
3. Verify the outcome of any actions you take

Think step by step. Be thorough. Take all warranted actions.
After all actions are complete, provide a brief summary of what you found and did.
""".strip()


# ─── TOOL DEFINITIONS (passed to Claude) ─────────────────────────────────────
def get_all_tools():
    return [
        {
            "name": "get_job_status",
            "description": "Get the current status of an Autosys job (SUCCESS, FAILURE, RUNNING, ON_ICE, INACTIVE)",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string", "description": "The Autosys job name/ID"}
                },
                "required": ["job_id"]
            }
        },
        {
            "name": "get_job_history",
            "description": "Get the run history of an Autosys job for the past N days",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string"},
                    "days":   {"type": "integer", "description": "Number of days of history (default 7)"}
                },
                "required": ["job_id"]
            }
        },
        {
            "name": "restart_job",
            "description": "Restart a failed or inactive Autosys job. Use only if policies allow auto-restart.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string", "description": "The Autosys job name to restart"}
                },
                "required": ["job_id"]
            }
        },
        {
            "name": "release_job_hold",
            "description": "Release an ON_ICE (held) Autosys job so it can run",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id": {"type": "string"}
                },
                "required": ["job_id"]
            }
        },
        {
            "name": "get_box_status",
            "description": "Get the status of an Autosys box (group of jobs)",
            "input_schema": {
                "type": "object",
                "properties": {
                    "box_name": {"type": "string"}
                },
                "required": ["box_name"]
            }
        },
        {
            "name": "verify_table_load",
            "description": "Verify that a Snowflake table was loaded today — checks load timestamp and row count",
            "input_schema": {
                "type": "object",
                "properties": {
                    "table_name": {"type": "string", "description": "Fully qualified or short table name"},
                    "schema":     {"type": "string", "description": "Snowflake schema (default: DW)"}
                },
                "required": ["table_name"]
            }
        },
        {
            "name": "get_row_count",
            "description": "Get current row count for a Snowflake table, optionally filtered",
            "input_schema": {
                "type": "object",
                "properties": {
                    "table_name":   {"type": "string"},
                    "where_clause": {"type": "string", "description": "Optional WHERE clause e.g. LOAD_DT = CURRENT_DATE"}
                },
                "required": ["table_name"]
            }
        },
        {
            "name": "get_load_errors",
            "description": "Get any load errors or rejected rows from Snowflake for a given table",
            "input_schema": {
                "type": "object",
                "properties": {
                    "table_name": {"type": "string"}
                },
                "required": ["table_name"]
            }
        },
        {
            "name": "compare_row_delta",
            "description": "Compare today's row count to yesterday's baseline — flags anomalies above threshold_pct",
            "input_schema": {
                "type": "object",
                "properties": {
                    "table_name":    {"type": "string"},
                    "threshold_pct": {"type": "number", "description": "Anomaly threshold percent (default 2.0)"}
                },
                "required": ["table_name"]
            }
        },
        {
            "name": "send_slack_alert",
            "description": "Send a Slack alert to a channel",
            "input_schema": {
                "type": "object",
                "properties": {
                    "channel":  {"type": "string", "description": "e.g. #etl-alerts"},
                    "message":  {"type": "string"},
                    "severity": {"type": "string", "enum": ["info", "warning", "critical"]}
                },
                "required": ["channel", "message"]
            }
        },
        {
            "name": "send_email_alert",
            "description": "Send an email alert to the data engineering team",
            "input_schema": {
                "type": "object",
                "properties": {
                    "recipients": {"type": "array", "items": {"type": "string"}},
                    "subject":    {"type": "string"},
                    "body":       {"type": "string"}
                },
                "required": ["recipients", "subject", "body"]
            }
        },
        {
            "name": "log_incident",
            "description": "Log an incident to the incident tracker for a failed or anomalous job",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id":      {"type": "string"},
                    "description": {"type": "string"},
                    "severity":    {"type": "string", "enum": ["low", "medium", "high", "critical"]}
                },
                "required": ["job_id", "description"]
            }
        },
        {
            "name": "check_sla_status",
            "description": "Check whether a running job is within its SLA window",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id":          {"type": "string"},
                    "elapsed_minutes": {"type": "number"}
                },
                "required": ["job_id", "elapsed_minutes"]
            }
        },
        {
            "name": "should_auto_restart",
            "description": "Check agent policy: is this job eligible for automatic restart?",
            "input_schema": {
                "type": "object",
                "properties": {
                    "job_id":        {"type": "string"},
                    "failure_count": {"type": "integer", "description": "How many times it has failed today"}
                },
                "required": ["job_id"]
            }
        },
    ]


# ─── SYSTEM PROMPT ────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """
You are an autonomous ETL monitoring agent running inside VS Code.
Your job is to autonomously monitor Autosys batch jobs and Snowflake data loads,
diagnose issues, take corrective actions, and alert the team — without human intervention.

You have tools to:
- Query Autosys job status and history
- Verify Snowflake table loads and row counts
- Restart failed jobs (within policy limits)
- Release held jobs when dependencies are met
- Send Slack and email alerts
- Log incidents

Rules for autonomous action:
1. Always check policy (should_auto_restart) before restarting any job
2. For FAILURE: investigate root cause via history before deciding action
3. For RUNNING: check SLA status — warn early, don't wait for miss
4. For SUCCESS: always verify Snowflake load and row count delta
5. For ON_ICE: check if predecessors are done, release if appropriate
6. Never restart a job more than twice without escalating
7. Flag anomalies but don't block pipelines on data quality checks alone
8. Always log incidents for failures and anomalies

Be decisive. Be thorough. Take action.
""".strip()


# ─── CLI ENTRYPOINT ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Autonomous ETL Monitoring Agent")
    parser.add_argument("--once",  action="store_true", help="Run one cycle and exit")
    parser.add_argument("--job",   type=str,            help="Monitor a specific job only")
    parser.add_argument("--env",   type=str, default="prod", choices=["prod", "uat", "dev"])
    args = parser.parse_args()

    config = AgentConfig.load(env=args.env)
    logger.info(f"Starting Autonomous ETL Agent (env={args.env}, once={args.once})")

    asyncio.run(run_agent(config, once=args.once, target_job=args.job))
