# Autonomous ETL Monitoring Agent

An autonomous AI agent that monitors Autosys batch jobs and Snowflake table loads,
makes decisions, and takes corrective actions — all without human intervention.

## Architecture

```
agent_loop.py                    ← Main autonomous loop (Observe→Think→Act→Update)
├── agents/
│   ├── orchestrator.py          ← Merges state, persists world model
│   ├── autosys_agent.py         ← Polls/controls Autosys (CLI or REST MCP)
│   ├── snowflake_agent.py       ← Verifies Snowflake loads & row counts
│   └── alert_agent.py           ← Slack, email, incident logging
└── config/
    ├── settings.py              ← Env-driven config (job map, SLAs, credentials)
    └── policies.py              ← Autonomous decision rules
```

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your Snowflake, Autosys MCP, Slack credentials
```

### 3. Register your jobs
Edit `config/settings.py` — add your job IDs and their Snowflake tables:
```python
job_table_map = {
    "YOUR_JOB_NAME":  "YOUR_SNOWFLAKE_TABLE",
    ...
}
job_sla_minutes = {
    "YOUR_JOB_NAME": 45,   # SLA in minutes
    ...
}
```

### 4. Start your Autosys MCP server
```bash
# Your custom MCP server (REST mode, default port 8080)
python autosys_mcp_server.py
```

### 5. Run the agent

**VS Code** — open Command Palette → `Tasks: Run Task` → `ETL Agent: Run Continuous Loop`

**Terminal:**
```bash
# Continuous loop (every 5 min)
python agent_loop.py

# Single cycle (debug / test)
python agent_loop.py --once

# Check one specific job
python agent_loop.py --once --job LOAD_SALES_FACT

# UAT environment
python agent_loop.py --env uat --once
```

## What the Agent Does Autonomously

| Scenario | Agent Action |
|---|---|
| Job = FAILURE (1st time) | Checks policy → auto-restarts → Slack alert → logs incident |
| Job = FAILURE (2nd+ time) | Escalates to #etl-oncall, does NOT restart |
| Job = RUNNING at 80% of SLA | Proactive Slack warning before SLA miss |
| Job = RUNNING at 95% of SLA | Critical alert to escalation channel |
| Job = ON_ICE, predecessors done | Releases hold automatically |
| Job = SUCCESS, rows OK | Verifies Snowflake timestamp, marks clean |
| Job = SUCCESS, row delta > 2% | Flags anomaly, does NOT block pipeline |
| Job = SUCCESS, 0 rows loaded | Critical alert — data quality issue |

## Logs

```
logs/
├── agent_YYYYMMDD.log       ← Full agent stdout/stderr
├── cycle_YYYYMMDD.jsonl     ← Every cycle's world state + actions (JSON Lines)
├── incidents.jsonl          ← Incident log
└── world_state.json         ← Latest state snapshot (used by next cycle)
```

## Autosys MCP Server (REST Mode)

The agent expects your Autosys MCP server at `AUTOSYS_MCP_URL` (default: `http://localhost:8080`).

Required endpoints:
```
GET  /jobs/{job_id}/status      → { status, last_start, last_end, elapsed_minutes, exit_code }
GET  /jobs/{job_id}/history     → { history: [...] }
POST /jobs/{job_id}/restart     → { status: "restarted" }
POST /jobs/{job_id}/release     → { status: "released" }
GET  /boxes/{box_name}          → { jobs: [...] }
```

## Extending the Agent

To add a new tool Claude can call:
1. Add the tool definition to `get_all_tools()` in `agent_loop.py`
2. Add the handler to `dispatch_tool()` in `agent_loop.py`
3. Implement the method in the appropriate agent class
4. Claude will automatically discover and use the new tool based on the description
